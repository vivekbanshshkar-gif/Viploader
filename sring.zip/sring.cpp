2328F0 // CASE 16

2 228168 // CASE 35

3 3A564C // VTABLE CHECK

4 malloc // OFFLINE

5 strcpy // VOLUTION

6 memcpy // 1 DAY FIX

7 monitor

8_ReadStatusReg(ARM64_SYSREG // 10 Years (No Others String)

9

10

11

12

13

14

15

16

17

18 TERMINATION FIX USE UE4 OFFSET

19

0x5CD9378

21- 0x6B20D14

22- 0x772E254

23

24_int64 (*osub_788F1C8)(_int64 a1, _int64 a2, _DWORD *a3);

25_int64 hsub_788F1C8(_int64 a1, _int64 a2, _DWORD *a3)

26

27 if (!a2 || !a3)

28 return osub_788F1C8(a1, a2, a3);

29 *(uint64_t*)(a2 + 32) = 0;

30 *(uint32_t*)a3 = 64;

31 return osub_788F1C8(a1, a2, a3);

32}






